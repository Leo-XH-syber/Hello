package com.njuse.seecjvm.instructions.conversion;

import com.njuse.seecjvm.instructions.base.NoOperandsInstruction;

import com.njuse.seecjvm.runtime.StackFrame;

public class I2D extends NoOperandsInstruction {

    /**
     * TODO：（加分项）实现这条指令
     * 这是一条可选测试用例才会涉及的指令
     */
    @Override
    public void execute(StackFrame frame) {
        int val = frame.getOperandStack().popInt();
        double ret = (double) val;
        frame.getOperandStack().pushDouble(ret);
    }
}

