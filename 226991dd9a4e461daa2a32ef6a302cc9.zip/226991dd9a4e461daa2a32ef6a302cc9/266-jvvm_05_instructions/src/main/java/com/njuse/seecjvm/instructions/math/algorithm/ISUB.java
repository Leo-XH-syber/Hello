package com.njuse.seecjvm.instructions.math.algorithm;

import com.njuse.seecjvm.instructions.base.NoOperandsInstruction;
import com.njuse.seecjvm.runtime.StackFrame;

public class ISUB extends NoOperandsInstruction {

    /**
     * TODO：实现这条指令
     */
    @Override
    public void execute(StackFrame frame) {
        int val_2 = frame.getOperandStack().popInt();
        int val_1 = frame.getOperandStack().popInt();
        int res = val_1 - val_2;
        frame.getOperandStack().pushInt(res);
    }
}
