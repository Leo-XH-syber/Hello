package com.njuse.seecjvm.instructions.comparison;

import com.njuse.seecjvm.instructions.base.NoOperandsInstruction;
import com.njuse.seecjvm.runtime.StackFrame;

public class DCMPG extends NoOperandsInstruction {

    /**
     * TODO：实现这条指令
     */
    @Override
    public void execute(StackFrame frame) {
        double val_2 = frame.getOperandStack().popDouble();
        double val_1 = frame.getOperandStack().popDouble();
        if (Double.isNaN(val_1) || Double.isNaN(val_2)){
            frame.getOperandStack().pushInt(1);
        }int ret = 0;
        if (val_1 == val_2){
            ret = 0;
        } else if (val_1 > val_2){
            ret = 1;
        } else if (val_1 < val_2){
            ret = -1;
        }
        frame.getOperandStack().pushInt(ret);
    }
}

